import urllib.request
import json

# Defining the function to get address
def address(lat,lon):
  url=f'https://api.bigdatacloud.net/data/reverse-geocode-client?latitude={lat}&longitude={lon}&localityLanguage=en'
  request = urllib.request.urlopen(url)
  result = json.loads(request.read())
  return result