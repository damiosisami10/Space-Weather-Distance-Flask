from flask import Flask, render_template
from get_iss import iss_loc
from get_weather import get_weather
from get_distance import dist
from get_country import country

app = Flask('app')

@app.route('/')
def home():
    # Get ISS location
    data = iss_loc()
    lat, lon = data[0], data[1]

    # Get weather information
    weather = get_weather(lat, lon)
    temp_and_weather = f"{round(weather['main']['temp'] - 273.15, 2)}°C ({weather['weather'][0]['description']})"

    # Calculate distance from ISS
    distance = dist(lat, lon, 46.5290876, -80.9432954)

    # Get country data
    iss_address = f"Latitude: {lat}, Longitude: {lon}"
    country_data = country('NG')  # Placeholder for demonstration; use actual country code
    if country_data:
        country_name = country_data['name']
        flag = country_data['flag']
        population = country_data['population']
    else:
        country_name = "Over Water"
        flag = None
        population = "N/A"

    # Display data on a webpage via a template
    return render_template('index.html', temp_and_weather=temp_and_weather,
                           country_name=country_name, population=population,
                           distance=distance, flag=flag, iss_address=iss_address)

app.run(host='0.0.0.0', port=8080)
