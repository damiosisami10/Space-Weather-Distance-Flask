import requests
import json

# Function to get country name,flag and population based on country code
def country(country_code):
    url = f"https://restcountries.com/v3.1/alpha/{country_code}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return {
            'name': data[0]['name']['common'],
            'flag': data[0]['flags']['png'],
            'population': data[0]['population']
        }
    else:
        return None
