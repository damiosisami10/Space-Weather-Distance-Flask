import urllib.request
import json


# Function to get weather information for ISS current location
def get_weather(lat,lon):
  #"Get the weather using lat and long from get_iss"
  key='6c5c3f98f4e39e89270007461205888f'
  url=f'https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={key}'
  request = urllib.request.urlopen(url)
  result = json.loads(request.read())
  return result
